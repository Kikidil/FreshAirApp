﻿<?php
@$mysqli = new PDO("mysql:host=localhost;dbname=freshair", 'root', '123456');
?>
