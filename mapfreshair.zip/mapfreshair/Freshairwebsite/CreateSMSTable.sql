

create table RecievedSMS
(
 SMSTitle char(255),
 SMSMessage char(255),
 RecievedFrom char(255),
 RecievedIp char(255)
 );


